# House Edge — final submission package (team penberthy-pushers)

This package holds both of our House Edge entries, clearly separated:

| Folder | Round | Model | What it is |
|---|---|---|---|
| `1_MAIN_ROUND_original_submission_v6/` | Main (60 pts) | **v6** | Our **original main-round submission**, unchanged since it was built on Sat Nov 7 |
| `2_ADAPTATION_ROUND_new_submission_v7/` | Adaptation (40 pts) | **v7** | Our **new round-two submission**, built after the adaptation data was released on Sun Nov 8 |

Each folder contains the two files uploaded for that round:

- **`*_submission.csv`:** the test forecast (1,536 queries, columns `query_id,p_0,p_1,p_2,p_5,p_20`).
- **`*_code_entry.zip`:** the code that recreates it. Each zip opens to `README.md` and `reproduce.json` and runs `python predict.py --data /data --out /output/submission.csv` with the Python standard library only.

The files are byte-for-byte the ones we produced for each round. They are renamed here only for clarity (originals: `runs/main-v6/{submission.csv,entry.zip}` and `runs/adapt-v7/{submission.csv,entry.zip}`). SHA-256 hashes are listed in `SHA256SUMS.txt`.

## What's original and what's new

**Main round, v6 (original).** Per-machine Bayesian model:
- the win chance is a logistic function of one XOR of past wins at a lag pair, (2,5), (1,3) or (4,7);
- Bayesian model averaging over the candidate pairs and signs;
- episode-level change-point detection, with a "same pair, flipped sign" prior after a change;
- a tied-coefficient prior;
- payout sizes from two hidden per-type modes, weighted by exported LightGBM trees.

**Adaptation round, v7 (new).** The adaptation data changed *which* lag pairs drive each machine: they are now (1,4), (3,8), (2,6). v6 scored only at reference level on it (9.91/20, about 19.8/40 on this rubric). v7 keeps v6's model and adds `learn_structure()`, which learns the round-specific settings from the round's own training split (`/data/train`) at run time instead of using fixed constants:
- the active lag pairs;
- the share of machines with no active pair;
- the prior midpoint line per machine type;
- the effect size and the prior spreads (empirical-Bayes method of moments).

The same v7 code rediscovers the main-round pairs on main data and the new pairs on adaptation data. Payout-size modes are identical in both rounds and were kept.

## Validation scores (60 / 40 rubric; points = max / (1 + R))

| Model | Main validation (of 60) | Adaptation validation (of 40) | Total (of 100) |
|---|---|---|---|
| v6 unchanged | 56.32 | 19.82 | 76.14 |
| **Submitted: v6 main + v7 adaptation** | **56.32** | **37.21** | **93.53** |

The main figure is the official checker's validation score. Part of v6's payout-size model was trained on main validation, so our held-out estimate for main is about 55.4, giving a total of about 92.6. The adaptation score is fully out-of-sample: nothing was tuned on adaptation validation. Test scores are private.

## Reproducibility

Both CSVs pass the official format checker for their round (`main | test` and `adaptation | test`). Each was recreated byte-for-byte from a fresh, read-only unzip of its code zip:
- **main:** about 15 s;
- **adaptation:** about 21 s, including learning from `/data/train`.
