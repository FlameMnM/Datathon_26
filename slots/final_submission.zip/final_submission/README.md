# House Edge — penberthy-pushers — Devpost submission files

Team name: **penberthy-pushers**. This package holds both House Edge rounds, clearly separated.

| Folder | Round | Model | Status |
|---|---|---|---|
| `1_MAIN_ROUND_original_submission_v6/` | **Main** (round one, 60 pts) | v6 | **Original main-round files, unchanged** (built Sat Nov 7) |
| `2_ADAPTATION_ROUND_submission_v7/` | **Adaptation** (round two, 40 pts) | v7 | **New adaptation-round files**, added after the round-two data release on Sun Nov 8 |

Each folder holds exactly the two files submitted for that round, with their original names:

- **`submission.csv`:** test forecast, 1,536 queries, columns `query_id,p_0,p_1,p_2,p_5,p_20`.
- **`entry.zip`:** code that recreates it. It contains `README.md` (team name and round), `reproduce.json`, the source code, the saved model files (`model.json`, `mode_lgb.json`), and, for adaptation, `requirements.txt`. The command is `python predict.py --data /data --out /output/submission.csv`, using the Python standard library only.

| File | SHA-256 |
|---|---|
| main `submission.csv` | `1e90bcd3db2aeb2fd2870bf316dea5dc63b7918541f0c210d8608bfde266dbaa` |
| main `entry.zip` | `7ab9bc41aa7ba8b0ebe8ccf937bdc42472be2da987353fe4bbaf852fc90fd61b` |
| adaptation `submission.csv` | `ebd69080f1ad34e96f9dd2f5ddf671ebbb7b858458504a7d3887105e46adb1a0` |
| adaptation `entry.zip` | `b2d0bc6f94f3812ef0833b789204a5d3f49d2ab372d80c919e8a0ea069cea3ca` |

## What's new in the adaptation round

The adaptation data changed which lag pairs drive each machine: (1,4), (3,8), (2,6) instead of (2,5), (1,3), (4,7). The unchanged main model scored only at reference level on it.

v7 keeps v6's model and learns the round-specific settings from the round's own training split (`/data/train`) at run time:
- the active lag pairs;
- the share of machines with no active pair;
- the prior settings, using empirical-Bayes method of moments.

The same code rediscovers the main-round pairs on main data.

## Validation scores (60 / 40 rubric)

| | Main (of 60) | Adaptation (of 40) | Total (of 100) |
|---|---|---|---|
| v6 unchanged | 56.32 | 19.82 | 76.14 |
| **Submitted: v6 main + v7 adaptation** | **56.32** | **37.21** | **93.53** |

Main is the official checker's validation score (held-out estimate about 55.4, because part of the size model was trained on main validation). Adaptation is fully out-of-sample. Both CSVs pass the official checker for their round, and each is recreated byte-for-byte from a fresh, read-only unzip of its `entry.zip`.
